---
name: NadiaVPN API scope
description: External endpoint capabilities and current bot coverage shared by the user
---

The user shared NadiaVPN examples for balance, server catalog, trial/order, renew, account list/detail/sync/delete, and quota checks with XL and Indosat providers. They also mentioned account migration and protocol changes as features not currently included in the bot; no request/response schema for those operations was provided.

SSH account details can include nested `config.port`, proxy settings, and payload variants; transaction balances/prices and server IDs are internal metadata, not buyer-facing connection details.

The Telegram bot is expected to run continuously on a VM. Only one polling process should use its bot token at a time.

The static DANA QRIS top-up has been removed. The user switched from Midtrans to QiosPay, which they confirmed has no sandbox. Their dashboard examples document dynamic invoices at `my.qiospay.com` with `x-api-key` plus HMAC-signed webhooks; the supplied SDK instead defaults to `app.qiospay.com` and Bearer auth. The redirect-link generator creates a real pending transaction when opened; its demo says production signatures must be computed server-side. Preserve the trial rule: members get one trial per day; the admin can take unlimited trials.

**Why:** The user supplied an actual SSH account response showing connection settings mixed with reseller transaction and server metadata, confirmed the trial behavior, asked for continuous bot availability, selected QiosPay after changing providers from Midtrans, shared conflicting QiosPay SDK and dashboard API examples, and confirmed the link generator is live-only.

**How to apply:** For order details, use the account-detail endpoint after a successful order when an account ID is available. Format protocol-specific configuration into labeled sections; do not dump the entire API response to the buyer. Run the bot as a single VM polling process and stop older instances before publishing. For QiosPay, prefer the user's invoice API examples over the SDK's conflicting defaults, validate the configured key with a read-only request first, verify webhook signatures and exact amounts, and credit each payment only once. Do not simulate or create a live invoice just to test; obtain explicit confirmation before a real-payment test. Keep the trial rule unchanged; keep quota, migration, and protocol-change features out of scope unless requested, and ask for their exact API schemas before implementing them.
